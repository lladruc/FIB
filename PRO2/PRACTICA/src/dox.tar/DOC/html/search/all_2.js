var searchData=
[
  ['data',['data',['../class_comanda.html#ab4ce0a50bde32145d11cbaee753526c7',1,'Comanda']]],
  ['delalltags',['delAllTags',['../class_event.html#a58e213ecfa7b2beedc275a2b4dc86eaf',1,'Event']]],
  ['delevent',['delEvent',['../class_agenda.html#a2420c913f02af745ffbd455428ddbc18',1,'Agenda']]],
  ['deltag',['delTag',['../class_agenda.html#a92735b9739edfdd888e6c8a50a9a9a1e',1,'Agenda::delTag()'],['../class_event.html#a7de280910bb66cc6a8370e9ad39282ee',1,'Event::delTag()']]],
  ['deltags',['delTags',['../class_agenda.html#aab25168e626608ef9c2cc251614fb657',1,'Agenda::delTags()'],['../class_tag.html#a3669460d494d74796e7380337d19689d',1,'Tag::delTags()']]]
];
