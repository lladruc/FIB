var searchData=
[
  ['vre',['vRe',['../class_agenda.html#a8ca8c9445b3f4435a6346ccc413327fc',1,'Agenda']]],
  ['vri',['vRi',['../class_agenda.html#aa182a77ef545679224988e47f7d889a1',1,'Agenda']]]
];
