var searchData=
[
  ['data',['data',['../class_comanda.html#ab4ce0a50bde32145d11cbaee753526c7',1,'Comanda']]],
  ['delalltags',['delAllTags',['../class_event.html#a58e213ecfa7b2beedc275a2b4dc86eaf',1,'Event']]],
  ['delevent',['delEvent',['../class_agenda.html#ae71248c9fc4536a04ee92e4702cf1f64',1,'Agenda']]],
  ['deltag',['delTag',['../class_event.html#a7bd83fe91f68446aee88fd69bd9ee388',1,'Event']]],
  ['deltags',['delTags',['../class_tag.html#aa51960a077ff0607087ea34500929450',1,'Tag']]]
];
