var searchData=
[
  ['rellotge',['Rellotge',['../class_rellotge.html#a32a5ede4b39b3dfc22a10d93a68d4173',1,'Rellotge']]],
  ['resultssize',['resultsSize',['../class_agenda.html#ab69c3b63cdac173d439aea0e821204c1',1,'Agenda']]],
  ['rollback',['rollBack',['../class_rellotge.html#a8bce0def81a1b01aae191ac678bf4473',1,'Rellotge']]]
];
