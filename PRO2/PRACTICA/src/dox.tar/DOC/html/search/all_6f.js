var searchData=
[
  ['operator_3c',['operator&lt;',['../class_rellotge.html#aec4d03763b1bfed2821e2df4a3923b19',1,'Rellotge']]]
];
