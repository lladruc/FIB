var searchData=
[
  ['histags',['hisTags',['../class_tag.html#a9374d4968679365fdc16f0b5e8792e51',1,'Tag']]],
  ['hora',['hora',['../class_comanda.html#ae8bca2ad702d3316dc1c53dcab7cac02',1,'Comanda']]]
];
