var searchData=
[
  ['pass_5fsearch',['pass_search',['../class_agenda.html#a15230e9ccd88c84d4333fe1e576d9724',1,'Agenda']]],
  ['printdate',['printDate',['../class_rellotge.html#abd7aa59db639ffc1e29154ba8283d7ed',1,'Rellotge']]],
  ['printdateandtime',['printDateAndTime',['../class_rellotge.html#abe2b43818a3c3283d499a4070efa6c7f',1,'Rellotge']]]
];
