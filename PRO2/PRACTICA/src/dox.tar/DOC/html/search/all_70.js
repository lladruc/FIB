var searchData=
[
  ['printdate',['printDate',['../class_rellotge.html#abd7aa59db639ffc1e29154ba8283d7ed',1,'Rellotge']]],
  ['printdateandtime',['printDateAndTime',['../class_rellotge.html#abe2b43818a3c3283d499a4070efa6c7f',1,'Rellotge']]]
];
