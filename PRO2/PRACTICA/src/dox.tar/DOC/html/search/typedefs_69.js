var searchData=
[
  ['ittag',['itTag',['../_tag_8cc.html#aa1ffaea98934d2496035b29e4bee1786',1,'itTag():&#160;Tag.cc'],['../_tag_8hh.html#aa1ffaea98934d2496035b29e4bee1786',1,'itTag():&#160;Tag.hh']]]
];
