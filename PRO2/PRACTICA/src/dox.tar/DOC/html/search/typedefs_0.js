var searchData=
[
  ['ittag',['itTag',['../tag_8cc.html#a2d6fad7c9cbf2182af0468da031f8518',1,'itTag():&#160;tag.cc'],['../tag_8hh.html#aa1ffaea98934d2496035b29e4bee1786',1,'itTag():&#160;tag.hh']]]
];
