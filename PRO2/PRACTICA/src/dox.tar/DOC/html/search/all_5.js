var searchData=
[
  ['getclock',['getClock',['../class_agenda.html#a2fa68356644c21af8972f96a6813cfaf',1,'Agenda']]],
  ['getdate',['getDate',['../class_rellotge.html#addfca1622b9aeba2cdff685060871153',1,'Rellotge']]],
  ['getdateandtime',['getDateAndTime',['../class_rellotge.html#a2ee21b1a870f7ca670e54cadeb0ee62d',1,'Rellotge']]],
  ['gettags',['getTags',['../class_event.html#ad17c21131ed964fc3498689e9f7413b4',1,'Event::getTags()'],['../class_tag.html#a56a7142948682324acd67ced26c96453',1,'Tag::getTags()']]],
  ['gettime',['getTime',['../class_rellotge.html#af7a5cf18e7903db9fbaffe526fcf5a06',1,'Rellotge']]],
  ['gettitol',['getTitol',['../class_event.html#a5a674a90725e7589757e98de7f109243',1,'Event']]]
];
