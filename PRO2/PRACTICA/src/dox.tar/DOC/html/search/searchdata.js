var indexSectionsWithContent =
{
  0: "acdefghilmnoprstv",
  1: "acert",
  2: "acert",
  3: "acdefghilmnoprstv",
  4: "i"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "typedefs"
};

var indexSectionLabels =
{
  0: "Todo",
  1: "Clases",
  2: "Archivos",
  3: "Funciones",
  4: "&apos;typedefs&apos;"
};

