var searchData=
[
  ['listmatchevents',['listMatchEvents',['../class_agenda.html#afed634afc41a8eecb28013c42dfd812a',1,'Agenda']]],
  ['llegir',['llegir',['../class_comanda.html#af2dbc8ccdbb94bed6ea26155edc71b57',1,'Comanda']]]
];
