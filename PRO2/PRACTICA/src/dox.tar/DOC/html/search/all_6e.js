var searchData=
[
  ['nombre_5fdates',['nombre_dates',['../class_comanda.html#aadabfc85ec7cdeb45039e8952a1ab124',1,'Comanda']]],
  ['nombre_5fetiquetes',['nombre_etiquetes',['../class_comanda.html#a4280b6ae2d435d9c21bbed364cb1db3d',1,'Comanda']]]
];
