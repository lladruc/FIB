var searchData=
[
  ['hora',['hora',['../class_comanda.html#ae8bca2ad702d3316dc1c53dcab7cac02',1,'Comanda']]]
];
