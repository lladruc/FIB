var searchData=
[
  ['rellotge',['Rellotge',['../class_rellotge.html',1,'Rellotge'],['../class_rellotge.html#a32a5ede4b39b3dfc22a10d93a68d4173',1,'Rellotge::Rellotge()']]],
  ['rellotge_2ecc',['Rellotge.cc',['../_rellotge_8cc.html',1,'']]],
  ['rellotge_2ehh',['Rellotge.hh',['../_rellotge_8hh.html',1,'']]],
  ['rollback',['rollBack',['../class_rellotge.html#a8bce0def81a1b01aae191ac678bf4473',1,'Rellotge']]]
];
