var searchData=
[
  ['search',['search',['../class_agenda.html#a2e07bd3ed34c3bd86455f7df9af40aef',1,'Agenda']]],
  ['setclock',['setClock',['../class_agenda.html#a80618f5a47f57db497057ff2c6767d0d',1,'Agenda']]],
  ['setdate',['setDate',['../class_rellotge.html#a19fc5ccb1b3949979f03f207f877c059',1,'Rellotge']]],
  ['settags',['setTags',['../class_event.html#ad8435cfd214339a65d51c08e548c8133',1,'Event']]],
  ['settime',['setTime',['../class_rellotge.html#a8b4ddc7c6b02397c415a2f0ca815dc04',1,'Rellotge']]],
  ['settimeanddate',['setTimeAndDate',['../class_rellotge.html#a418c7be8bf66f6e27291d6b77dcd969f',1,'Rellotge']]],
  ['settitol',['setTitol',['../class_event.html#a16ed22cc72c0249ade170184f280a1d8',1,'Event']]],
  ['sre',['sRe',['../class_event.html#a493830148bdab7c4ae1210d7cee91b81',1,'Event']]]
];
