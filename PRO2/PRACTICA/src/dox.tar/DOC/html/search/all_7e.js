var searchData=
[
  ['_7eagenda',['~Agenda',['../class_agenda.html#a2344fe71f31e64ad95bf8d893e9d1025',1,'Agenda']]],
  ['_7eevent',['~Event',['../class_event.html#a7704ec01ce91e673885792054214b3d2',1,'Event']]],
  ['_7erellotge',['~Rellotge',['../class_rellotge.html#a7dd3788879bfb6014e35d770d5f7e228',1,'Rellotge']]]
];
