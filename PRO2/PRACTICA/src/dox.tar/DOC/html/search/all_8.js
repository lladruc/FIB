var searchData=
[
  ['listmatchevents',['listMatchEvents',['../class_agenda.html#a79f0deb9f644e512b2b143fd60b1bcd5',1,'Agenda']]],
  ['llegir',['llegir',['../class_comanda.html#af2dbc8ccdbb94bed6ea26155edc71b57',1,'Comanda']]]
];
